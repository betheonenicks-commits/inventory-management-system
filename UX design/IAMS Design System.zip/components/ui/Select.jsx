import * as React from "react";

export function Select({ className = "", ...props }) {
  return <select className={`iams-select ${className}`} {...props}></select>;
}
