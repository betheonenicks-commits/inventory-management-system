IAMS button — use for all actions; gold `primary` for the single main action per view, `secondary` for supporting actions, `ghost` for icon/toolbar actions.

```jsx
<Button>+ Register asset</Button>
<Button variant="secondary">Sign in with SSO</Button>
<Button variant="ghost" size="icon"><Icon name="bell" size={17} /></Button>
```

Sizes: `default` (10×16px pad), `sm` (13px text), `icon` (34×34). Press = scale 0.98; focus = gold ring.
