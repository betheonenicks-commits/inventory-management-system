IAMS text input — pair with `Label` above it.

```jsx
<Label htmlFor="email">Email or username</Label>
<Input id="email" type="text" placeholder="elena.m@example.org" />
```

Focus: gold border + soft gold ring. Placeholder is tertiary slate.
