Native select styled identically to Input (kit deliberately uses native selects).

```jsx
<Select defaultValue="it">
  <option value="it">IT equipment</option>
  <option value="av">AV equipment</option>
</Select>
```
