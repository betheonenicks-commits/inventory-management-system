import * as React from "react";

export function Table({ className = "", children, ...props }) {
  return (
    <div className="iams-table-wrap">
      <table className={`iams-table ${className}`} {...props}>{children}</table>
    </div>
  );
}

export function Th({ className = "", ...props }) {
  return <th className={className} {...props}></th>;
}

export function Td({ className = "", ...props }) {
  return <td className={className} {...props}></td>;
}

export function Tr({ link, className = "", ...props }) {
  return <tr className={`${link ? "iams-tr-link" : ""} ${className}`} {...props}></tr>;
}
