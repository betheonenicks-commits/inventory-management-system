/** Native select styled to match Input. */
export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {}
export declare function Select(props: SelectProps): JSX.Element;
