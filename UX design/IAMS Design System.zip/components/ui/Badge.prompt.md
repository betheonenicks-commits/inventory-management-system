IAMS status badge — rounded pill with a tone dot; used for asset/user statuses. Prefer `StatusPill` when mapping domain status strings.

```jsx
<Badge tone="verify">In use</Badge>
<Badge tone="amber">Under repair</Badge>
<Badge tone="rust">Missing</Badge>
<Badge tone="slate" dot={false}>In storage</Badge>
```
