IAMS data table primitives. Wrap in a `Card` with `padding: 0`. Set `link` on `Tr` for clickable record rows.

```jsx
<Table>
  <thead><tr><Th>Asset</Th><Th>Status</Th></tr></thead>
  <tbody>
    <Tr link onClick={open}><Td>Dell Latitude 5440</Td><Td><Badge tone="verify">In use</Badge></Td></Tr>
  </tbody>
</Table>
```
