/** IAMS data table — 13px body, uppercase 11.5px headers, hairline row borders. */
export interface TableProps extends React.HTMLAttributes<HTMLTableElement> {}
export declare function Table(props: TableProps): JSX.Element;

export interface ThProps extends React.ThHTMLAttributes<HTMLTableCellElement> {}
export declare function Th(props: ThProps): JSX.Element;

export interface TdProps extends React.TdHTMLAttributes<HTMLTableCellElement> {}
export declare function Td(props: TdProps): JSX.Element;

export interface TrProps extends React.HTMLAttributes<HTMLTableRowElement> {
  /** Row is clickable — paper hover, pointer cursor. */
  link?: boolean;
}
export declare function Tr(props: TrProps): JSX.Element;
