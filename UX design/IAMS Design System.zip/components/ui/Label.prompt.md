Form field label — always above the field.

```jsx
<Label htmlFor="password">Password</Label>
<Input id="password" type="password" />
```
