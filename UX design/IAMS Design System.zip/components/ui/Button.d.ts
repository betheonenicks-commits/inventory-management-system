/** IAMS button. Gold primary, hairline secondary, quiet ghost. */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual style. @default "primary" */
  variant?: "primary" | "secondary" | "ghost";
  /** @default "default" */
  size?: "default" | "sm" | "icon";
}
export declare function Button(props: ButtonProps): JSX.Element;
