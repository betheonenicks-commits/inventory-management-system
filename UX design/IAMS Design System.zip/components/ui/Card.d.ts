/** IAMS card — 12px radius, hairline border, soft two-layer shadow. */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {}
export declare function Card(props: CardProps): JSX.Element;

/** Card heading — 14px/600, 16px bottom margin. */
export interface CardTitleProps extends React.HTMLAttributes<HTMLHeadingElement> {}
export declare function CardTitle(props: CardTitleProps): JSX.Element;
