import * as React from "react";

export function Button({ variant = "primary", size = "default", className = "", ...props }) {
  return (
    <button
      className={`iams-btn iams-btn-${variant} iams-btn-size-${size} ${className}`}
      {...props}
    ></button>
  );
}
