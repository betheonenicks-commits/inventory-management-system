/** Form label — 12px/500 slate, 6px bottom margin. */
export interface LabelProps extends React.LabelHTMLAttributes<HTMLLabelElement> {}
export declare function Label(props: LabelProps): JSX.Element;
