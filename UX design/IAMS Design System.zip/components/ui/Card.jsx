import * as React from "react";

export function Card({ className = "", ...props }) {
  return <div className={`iams-card ${className}`} {...props}></div>;
}

export function CardTitle({ className = "", ...props }) {
  return <h3 className={`iams-card-title ${className}`} {...props}></h3>;
}
