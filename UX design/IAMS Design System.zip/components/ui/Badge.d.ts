/** IAMS status badge — pill with tone dot (verify/amber/rust/slate). */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Semantic tone. @default "slate" */
  tone?: "verify" | "amber" | "rust" | "slate";
  /** Show the leading status dot. @default true */
  dot?: boolean;
}
export declare function Badge(props: BadgeProps): JSX.Element;
