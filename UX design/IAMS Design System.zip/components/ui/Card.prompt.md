IAMS card — the universal container (metrics, tables, panels). 20px padding by default; set `style={{padding:0}}` when a table fills it edge-to-edge.

```jsx
<Card>
  <CardTitle>Recent activity</CardTitle>
  …
</Card>
```
