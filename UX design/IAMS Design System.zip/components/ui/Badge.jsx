import * as React from "react";

const dotClass = {
  verify: "var(--success)",
  amber: "var(--warning)",
  rust: "var(--danger)",
  slate: "var(--text-tertiary)",
};

export function Badge({ tone = "slate", dot = true, children, className = "", ...props }) {
  return (
    <span className={`iams-badge iams-badge-${tone} ${className}`} {...props}>
      {dot && <span className="iams-badge-dot" style={{ background: dotClass[tone] }}></span>}
      {children}
    </span>
  );
}
