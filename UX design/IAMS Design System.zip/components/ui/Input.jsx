import * as React from "react";

export function Input({ className = "", ...props }) {
  return <input className={`iams-input ${className}`} {...props} />;
}
