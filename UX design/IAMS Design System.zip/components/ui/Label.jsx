import * as React from "react";

export function Label({ className = "", ...props }) {
  return <label className={`iams-label ${className}`} {...props}></label>;
}
