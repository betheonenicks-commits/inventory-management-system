/** Maps a domain status string ("In use", "Missing", "Active"…) to the right Badge tone. */
export interface StatusPillProps {
  status: string;
}
export declare function StatusPill(props: StatusPillProps): JSX.Element;
