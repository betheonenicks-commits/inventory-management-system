Asset register table — the canonical list view (asset list, label queue). Wrap in `<Card style={{padding:0}}>`.

```jsx
<Card style={{padding:0}}>
  <AssetTable rows={assets} onOpen={(a) => openRecord(a.id)} />
</Card>
```
