import * as React from "react";
import { Card } from "../ui/Card.jsx";
import { Icon } from "./Icon.jsx";

/** Placeholder for screens defined in the IA but outside Release R1 scope. */
export function LockPanel({ name }) {
  return (
    <Card style={{ padding: 48, textAlign: "center" }}>
      <span style={{ color: "var(--text-tertiary)", display: "inline-block", marginBottom: 14 }}>
        <Icon name="lock" size={32} />
      </span>
      <p style={{ margin: "0 0 4px", fontSize: 14, fontWeight: 500 }}>{name} is scoped for a later release</p>
      <p style={{ margin: 0, fontSize: 12.5, color: "var(--text-secondary)" }}>
        This screen is defined in the Information Architecture but out of Release R1 (MVP) scope.
      </p>
    </Card>
  );
}
