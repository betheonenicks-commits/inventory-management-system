Recent-activity event list (dashboard, activity log). Green dot = normal, rust dot = alert.

```jsx
<ActivityFeed items={[
  { text: "AST-00482 assigned to Elena Marsh", time: "2 hours ago" },
  { text: "AST-00701 flagged Missing", time: "3 days ago", severity: "alert" },
]} />
```
