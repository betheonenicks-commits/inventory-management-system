/** App header — breadcrumb, global search, theme toggle, bell with rust dot, mono avatar. */
export interface TopbarProps {
  breadcrumb?: string;
  /** Current theme, controls sun/moon glyph. @default false */
  dark?: boolean;
  onToggleTheme?: () => void;
  onBell?: () => void;
  /** @default "EM" */
  initials?: string;
  /** @default "Elena Marsh" */
  userLabel?: string;
}
export declare function Topbar(props: TopbarProps): JSX.Element;
