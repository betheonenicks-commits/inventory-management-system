/** Locked-module placeholder for R2 screens (Stock, Transfers, Audits, Integrations). */
export interface LockPanelProps {
  /** Module name, e.g. "Stock list". */
  name: string;
}
export declare function LockPanel(props: LockPanelProps): JSX.Element;
