import * as React from "react";
import { Badge } from "../ui/Badge.jsx";

const toneMap = {
  "In use": "verify",
  "In storage": "slate",
  "Under repair": "amber",
  Missing: "rust",
  Active: "verify",
  Offboarding: "amber",
  "Pending Delivery": "amber",
  Received: "verify",
};

/** Maps any domain status string to the correct badge tone. */
export function StatusPill({ status }) {
  return <Badge tone={toneMap[status] || "slate"}>{status}</Badge>;
}
