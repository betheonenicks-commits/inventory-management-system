/** Lucide icon rendered as a currentColor mask. */
export interface IconProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Glyph name, kebab-case (e.g. "package", "shield-check"). */
  name: "layout-dashboard" | "package" | "tag" | "boxes" | "arrow-left-right" | "clipboard-check" | "file-text" | "network" | "users" | "shield" | "shield-check" | "plug" | "bell" | "search" | "lock" | "sun" | "moon";
  /** px size. @default 16 */
  size?: number;
}
export declare function Icon(props: IconProps): JSX.Element;
