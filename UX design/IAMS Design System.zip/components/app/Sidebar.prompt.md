The app sidebar — always 232px wide, ink background, full-height. Out-of-scope modules carry mono "R2" tags. Active item: ink-2 bg + 3px gold bar.

```jsx
<Sidebar activeHref="/assets" onNavigate={setRoute} />
```

`NAVIGATION` (the full IAMS IA) is also exported for reuse.
