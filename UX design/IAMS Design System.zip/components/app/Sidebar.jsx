import * as React from "react";
import { Seal } from "./Seal.jsx";
import { Icon } from "./Icon.jsx";

/** Default navigation — mirrors lib/data.ts verbatim. */
export const NAVIGATION = [
  { label: "Overview", items: [{ id: "dsh-01", name: "Dashboard", href: "/dashboard", icon: "layout-dashboard", r1: true }] },
  { label: "Assets", items: [
    { id: "ast-01", name: "Asset list", href: "/assets", icon: "package", r1: true },
    { id: "ast-04", name: "Label queue", href: "/labels", icon: "tag", r1: true },
  ]},
  { label: "Inventory", items: [{ id: "inv-01", name: "Stock list", href: "/stock", icon: "boxes", r1: false }] },
  { label: "Lifecycle", items: [{ id: "lif-02", name: "Transfers", href: "/transfers", icon: "arrow-left-right", r1: false }] },
  { label: "Audits", items: [{ id: "aud-01", name: "Audit list", href: "/audits", icon: "clipboard-check", r1: false }] },
  { label: "Reports", items: [{ id: "rpt-01", name: "Report catalog", href: "/reports", icon: "file-text", r1: true }] },
  { label: "Organization", items: [{ id: "org-01", name: "Hierarchy", href: "/hierarchy", icon: "network", r1: true }] },
  { label: "Users", items: [{ id: "usr-01", name: "Users", href: "/users", icon: "users", r1: true }] },
  { label: "Security", items: [
    { id: "sec-01", name: "Activity log", href: "/activity", icon: "shield", r1: true },
    { id: "cmp-01", name: "Retention policy", href: "/retention", icon: "shield-check", r1: true },
  ]},
  { label: "Integrations", items: [{ id: "int-01", name: "Integrations", href: "/integrations", icon: "plug", r1: false }] },
];

export function Sidebar({ activeHref = "/dashboard", onNavigate, navigation = NAVIGATION, signedInAs = "elena.m@example.org" }) {
  return (
    <nav aria-label="Primary" className="iams-sidebar">
      <a className="iams-sidebar-brand" onClick={() => onNavigate && onNavigate("/dashboard")} style={{ cursor: "pointer" }}>
        <Seal size={22} />
        <span>IAMS</span>
      </a>

      {navigation.map((group) => (
        <div key={group.label}>
          <p className="iams-nav-group">{group.label}</p>
          {group.items.map((item) => {
            const active = activeHref.startsWith(item.href);
            return (
              <a
                key={item.id}
                aria-current={active ? "page" : undefined}
                className="iams-nav-item"
                onClick={() => onNavigate && onNavigate(item.href)}
              >
                {active && <span className="iams-nav-active-bar"></span>}
                <Icon name={item.icon} size={16} style={{ opacity: 0.85 }} />
                <span>{item.name}</span>
                {!item.r1 && <span className="iams-nav-r2">R2</span>}
              </a>
            );
          })}
        </div>
      ))}

      <div className="iams-sidebar-footer">
        Signed in as
        <br />
        <span className="email">{signedInAs}</span>
      </div>
    </nav>
  );
}
