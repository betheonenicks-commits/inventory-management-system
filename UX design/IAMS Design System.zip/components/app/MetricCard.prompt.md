Dashboard KPI stat — shown in a 2/4-column grid at the top of the dashboard.

```jsx
<MetricCard label="Total assets" value={8} delta="Main Campus" />
<MetricCard label="Missing" value={1} delta="Needs review" deltaTone="warn" />
```
