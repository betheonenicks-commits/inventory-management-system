import * as React from "react";
import { Card } from "../ui/Card.jsx";

const deltaColor = {
  up: "var(--success)",
  warn: "var(--danger)",
  neutral: "var(--text-secondary)",
};

export function MetricCard({ label, value, delta, deltaTone = "neutral" }) {
  return (
    <Card style={{ padding: "16px 18px" }}>
      <p style={{ margin: "0 0 8px", fontSize: 12.5, color: "var(--text-secondary)" }}>{label}</p>
      <p style={{ margin: 0, fontFamily: "var(--font-mono)", fontSize: 26, fontWeight: 500, letterSpacing: "var(--tracking-tight)" }}>{value}</p>
      {delta && (
        <p style={{ margin: "6px 0 0", fontSize: 11.5, color: deltaColor[deltaTone] }}>{delta}</p>
      )}
    </Card>
  );
}
