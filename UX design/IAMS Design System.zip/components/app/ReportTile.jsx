import * as React from "react";
import { Icon } from "./Icon.jsx";

/** Report catalog tile — icon, title, description; hover lifts 1px with gold border. */
export function ReportTile({ icon = "file-text", title, desc, onClick }) {
  return (
    <button className="iams-report-tile" onClick={onClick}>
      <span style={{ color: "var(--accent)", display: "inline-block", marginBottom: 10 }}>
        <Icon name={icon} size={16} />
      </span>
      <p style={{ margin: "0 0 2px", fontSize: 13.5, fontWeight: 500, color: "var(--text-body)" }}>{title}</p>
      <p style={{ margin: 0, fontSize: 12, color: "var(--text-secondary)" }}>{desc}</p>
    </button>
  );
}
