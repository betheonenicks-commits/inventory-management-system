Every screen starts with a PageHeader. The `sub` line carries the screen code in mono.

```jsx
<PageHeader
  title="Asset list"
  sub={<>Screen <span style={{fontFamily:"var(--font-mono)", fontSize:12}}>SCR-AST-01</span> · click a row to open the record</>}
  actions={<Button>+ Register asset</Button>}
/>
```
