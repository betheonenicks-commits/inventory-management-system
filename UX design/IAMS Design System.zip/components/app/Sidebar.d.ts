/** Primary navigation — ink panel, grouped mono labels, gold active bar, R2 tags. */
export interface SidebarProps {
  /** Href of the active route. @default "/dashboard" */
  activeHref?: string;
  onNavigate?: (href: string) => void;
  /** Nav groups; defaults to the full IAMS IA (exported as NAVIGATION). */
  navigation?: { label: string; items: { id: string; name: string; href: string; icon: string; r1: boolean }[] }[];
  /** @default "elena.m@example.org" */
  signedInAs?: string;
}
export declare function Sidebar(props: SidebarProps): JSX.Element;
