import * as React from "react";

export function ActivityFeed({ items = [] }) {
  return (
    <ul style={{ margin: 0, listStyle: "none", padding: 0 }}>
      {items.map((item, i) => (
        <li
          key={i}
          style={{
            display: "flex", gap: 10, padding: "10px 0", fontSize: 12.5,
            borderBottom: i === items.length - 1 ? "none" : "1px solid var(--border-hairline)",
          }}
        >
          <span
            style={{
              marginTop: 6, height: 6, width: 6, flexShrink: 0, borderRadius: "50%",
              background: item.severity === "alert" ? "var(--danger)" : "var(--success)",
            }}
          ></span>
          <div>
            <p style={{ margin: 0 }}>{item.text}</p>
            <span style={{ fontSize: 11, color: "var(--text-tertiary)" }}>{item.time}</span>
          </div>
        </li>
      ))}
    </ul>
  );
}
