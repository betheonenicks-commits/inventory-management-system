App header bar — sits right of the sidebar, above the scrollable content.

```jsx
<Topbar breadcrumb="Assets / Asset list" dark={dark} onToggleTheme={toggle} />
```
