/** Report catalog tile — gold icon, hover lift + gold border. */
export interface ReportTileProps {
  /** Lucide glyph name. @default "file-text" */
  icon?: string;
  title: string;
  desc: string;
  onClick?: () => void;
}
export declare function ReportTile(props: ReportTileProps): JSX.Element;
