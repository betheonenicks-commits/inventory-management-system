Lucide icon wrapper (the kit's icon system), colored via `currentColor`. Nav icons: 16px; topbar bell: 17px.

```jsx
<Icon name="package" size={16} />
<span style={{color: "var(--accent)"}}><Icon name="file-text" /></span>
```

Only the 17 glyphs the product uses are bundled — see `assets/icons/`.
