Placeholder card for out-of-scope (R2) modules — never invent UI for locked screens; show this instead.

```jsx
<LockPanel name="Stock list" />
```
