Report catalog tile — shown in a 3-column grid on SCR-RPT-01.

```jsx
<ReportTile icon="package" title="Asset register" desc="Full list, exportable to PDF/Excel/CSV" />
```
