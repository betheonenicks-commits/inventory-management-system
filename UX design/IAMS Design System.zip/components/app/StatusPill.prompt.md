Status pill — always use this (not raw Badge) for asset/user statuses so tones stay consistent. Known: In use→verify, In storage→slate, Under repair→amber, Missing→rust, Active→verify, Offboarding→amber, Pending Delivery→amber, Received→verify; unknown→slate.

```jsx
<StatusPill status="Under repair" />
```
