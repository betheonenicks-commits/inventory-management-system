/** Event list with severity dots and hairline separators. */
export interface ActivityFeedProps {
  items: { text: string; time: string; severity?: "alert" }[];
}
export declare function ActivityFeed(props: ActivityFeedProps): JSX.Element;
