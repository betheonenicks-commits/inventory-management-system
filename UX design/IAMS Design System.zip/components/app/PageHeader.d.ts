/** Page title row — 21px/600 title, 13px slate sub, actions right-aligned. */
export interface PageHeaderProps {
  title: string;
  /** Screen code + FR references, e.g. "Screen SCR-AST-01 · FR-AST-01" */
  sub?: React.ReactNode;
  actions?: React.ReactNode;
}
export declare function PageHeader(props: PageHeaderProps): JSX.Element;
