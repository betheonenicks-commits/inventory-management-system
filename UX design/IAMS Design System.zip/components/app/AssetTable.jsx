import * as React from "react";
import { Table, Th, Td, Tr } from "../ui/Table.jsx";
import { StatusPill } from "./StatusPill.jsx";

/** Clickable asset table — rows navigate to the asset record. */
export function AssetTable({ rows = [], onOpen }) {
  return (
    <Table>
      <thead>
        <tr>
          <Th>Asset</Th>
          <Th>Category</Th>
          <Th>Location</Th>
          <Th>Assigned to</Th>
          <Th>Status</Th>
        </tr>
      </thead>
      <tbody>
        {rows.map((a) => (
          <Tr
            key={a.id}
            link
            role="link"
            tabIndex={0}
            onClick={() => onOpen && onOpen(a)}
            onKeyDown={(e) => e.key === "Enter" && onOpen && onOpen(a)}
          >
            <Td>
              <span style={{ fontFamily: "var(--font-mono)", fontSize: 12.5, color: "var(--success-deep)" }}>{a.id}</span>
              <br />
              <span style={{ fontSize: 13 }}>{a.name}</span>
            </Td>
            <Td>{a.category}</Td>
            <Td>{a.location}</Td>
            <Td>{a.assignee || "—"}</Td>
            <Td><StatusPill status={a.status} /></Td>
          </Tr>
        ))}
      </tbody>
    </Table>
  );
}
