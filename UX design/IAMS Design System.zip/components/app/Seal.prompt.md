IAMS brand seal — the verification mark used everywhere a logo goes (sidebar 22px, login form 38px, login hero 46px). Colors are fixed (#3A4566 navy ring, #B08D3F gold ring + check) in both themes.

```jsx
<Seal size={22} /> <span>IAMS</span>
```
