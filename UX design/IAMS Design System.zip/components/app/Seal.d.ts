/** IAMS brand seal — concentric navy/gold rings with a gold check. The only logo mark. */
export interface SealProps {
  /** Rendered px size. @default 26 */
  size?: number;
}
export declare function Seal(props: SealProps): JSX.Element;
