/** Dashboard KPI card — mono 26px value, optional toned delta line. */
export interface MetricCardProps {
  label: string;
  value: string | number;
  delta?: string;
  /** @default "neutral" */
  deltaTone?: "up" | "warn" | "neutral";
}
export declare function MetricCard(props: MetricCardProps): JSX.Element;
