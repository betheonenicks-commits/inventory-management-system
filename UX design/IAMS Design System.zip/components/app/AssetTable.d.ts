/** Clickable asset register table — mono verify-deep IDs, StatusPill statuses. */
export interface AssetTableProps {
  rows: {
    id: string; name: string; category: string; location: string;
    assignee?: string | null; status: string;
  }[];
  /** Row click/Enter handler. */
  onOpen?: (asset: any) => void;
}
export declare function AssetTable(props: AssetTableProps): JSX.Element;
