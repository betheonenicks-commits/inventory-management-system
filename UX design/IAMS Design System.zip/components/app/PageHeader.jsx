import * as React from "react";

export function PageHeader({ title, sub, actions }) {
  return (
    <div style={{ marginBottom: 20, display: "flex", flexWrap: "wrap", alignItems: "flex-start", justifyContent: "space-between", gap: 12 }}>
      <div>
        <h1 style={{ margin: 0, fontSize: 21, fontWeight: 600, letterSpacing: "var(--tracking-tight)" }}>{title}</h1>
        {sub && <p style={{ margin: "4px 0 0", fontSize: 13, color: "var(--text-secondary)" }}>{sub}</p>}
      </div>
      {actions}
    </div>
  );
}
