import * as React from "react";
import { Icon } from "./Icon.jsx";
import { Button } from "../ui/Button.jsx";

export function Topbar({ breadcrumb, dark = false, onToggleTheme, onBell, initials = "EM", userLabel = "Elena Marsh" }) {
  return (
    <header className="iams-topbar">
      {breadcrumb && <p style={{ margin: 0, fontSize: 13, color: "var(--text-secondary)" }}>{breadcrumb}</p>}

      <div className="iams-search">
        <Icon name="search" size={14} />
        <input type="search" placeholder="Search assets, people, orders" aria-label="Global search" />
      </div>

      <div style={{ flex: 1 }}></div>

      <Button variant="ghost" size="icon" aria-label="Toggle theme" onClick={onToggleTheme}>
        <Icon name={dark ? "sun" : "moon"} size={16} />
      </Button>

      <Button variant="ghost" size="icon" aria-label="Notifications" onClick={onBell} style={{ position: "relative" }}>
        <Icon name="bell" size={17} />
        <span style={{
          position: "absolute", right: 7, top: 6, height: 7, width: 7,
          borderRadius: "50%", border: "1.5px solid var(--surface-card)", background: "var(--danger)",
        }}></span>
      </Button>

      <div aria-label={userLabel} className="iams-avatar">{initials}</div>
    </header>
  );
}
