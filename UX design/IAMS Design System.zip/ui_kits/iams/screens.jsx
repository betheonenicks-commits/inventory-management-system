// IAMS UI kit screens — recreations of SCR-GLB-01, SCR-DSH-01, SCR-AST-01/02, SCR-USR-01, SCR-RPT-01 + R2 locks.
const DS = window.IAMSDesignSystem_1406c8;
const { Seal, Icon, Button, Input, Select, Label, Card, CardTitle, Table, Th, Td, Tr,
  Badge, StatusPill, PageHeader, MetricCard, ActivityFeed, AssetTable, ReportTile, LockPanel } = DS;
const { assets, users, recentActivity, reports } = window.IAMS_DATA;

/* ── SCR-GLB-01 · Login ─────────────────────────────── */
function LoginScreen({ onSignIn }) {
  return (
    <div style={{ display: "grid", minHeight: "100vh", gridTemplateColumns: "1fr 1fr" }} data-screen-label="Login SCR-GLB-01">
      <div style={{ position: "relative", display: "flex", flexDirection: "column", justifyContent: "center", overflow: "hidden", background: "hsl(var(--ink))", padding: 80, color: "#fff" }}>
        <div aria-hidden="true" style={{ position: "absolute", bottom: -176, right: -176, height: 480, width: 480, borderRadius: "50%", border: "1px solid hsl(var(--ink-border))" }}></div>
        <div aria-hidden="true" style={{ position: "absolute", bottom: -80, right: -80, height: 300, width: 300, borderRadius: "50%", border: "1px solid hsl(var(--ink-border))" }}></div>
        <div style={{ marginBottom: 32 }}><Seal size={46} /></div>
        <h1 style={{ margin: "0 0 12px", fontSize: 30, fontWeight: 600, lineHeight: 1.25, letterSpacing: "var(--tracking-tight)" }}>
          Every asset accounted for.<br />Every audit provable.
        </h1>
        <p style={{ margin: "0 0 40px", maxWidth: 360, fontSize: 15, lineHeight: 1.625, color: "hsl(var(--ink-text-dim))" }}>
          IAMS is the on-premises system of record for physical assets and audits — built so nothing has to be taken on trust.
        </p>
        <dl style={{ display: "flex", gap: 40, margin: 0 }}>
          {[["41", "screens mapped"], ["16", "modules"], ["100%", "on-premises"]].map(([value, label]) => (
            <div key={label}>
              <dd style={{ margin: 0, fontFamily: "var(--font-mono)", fontSize: 22, letterSpacing: "var(--tracking-tight)" }}>{value}</dd>
              <dt style={{ marginTop: 2, fontSize: 12, color: "hsl(var(--ink-text-dim))" }}>{label}</dt>
            </div>
          ))}
        </dl>
      </div>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 32 }}>
        <form style={{ width: "100%", maxWidth: 340 }} onSubmit={(e) => { e.preventDefault(); onSignIn(); }}>
          <h2 style={{ margin: "0 0 6px", fontSize: 20, fontWeight: 600, letterSpacing: "var(--tracking-tight)" }}>Sign in to IAMS</h2>
          <p style={{ margin: "0 0 32px", fontSize: 13, color: "var(--text-secondary)" }}>Main Campus deployment</p>
          <div style={{ marginBottom: 16 }}>
            <Label htmlFor="email">Email or username</Label>
            <Input id="email" type="text" defaultValue="elena.m@example.org" autoComplete="username" />
          </div>
          <div style={{ marginBottom: 16 }}>
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" defaultValue="0000000000" autoComplete="current-password" />
          </div>
          <Button type="submit" style={{ width: "100%" }}>Sign in</Button>
          <div style={{ margin: "18px 0", display: "flex", alignItems: "center", gap: 10, fontSize: 12, color: "var(--text-tertiary)" }}>
            <span style={{ height: 1, flex: 1, background: "var(--border-hairline)" }}></span>
            or
            <span style={{ height: 1, flex: 1, background: "var(--border-hairline)" }}></span>
          </div>
          <Button type="button" variant="secondary" style={{ width: "100%" }}>Sign in with SSO</Button>
          <p style={{ marginTop: 22, textAlign: "center", fontSize: 12, color: "var(--text-tertiary)" }}>
            Screen SCR-GLB-01 · FR-SEC-01, FR-SEC-02
          </p>
        </form>
      </div>
    </div>
  );
}

/* ── SCR-DSH-01 · Dashboard ─────────────────────────── */
function DashboardScreen() {
  const count = (s) => assets.filter((a) => a.status === s).length;
  const bars = [
    { label: "In use", value: count("In use"), bg: "var(--success)" },
    { label: "Storage", value: count("In storage"), bg: "var(--success-soft)" },
    { label: "Repair", value: count("Under repair"), bg: "var(--success-soft)" },
    { label: "Missing", value: count("Missing"), bg: "var(--danger-soft)" },
  ];
  return (
    <div data-screen-label="Dashboard SCR-DSH-01">
      <PageHeader title="Executive dashboard"
        sub={<React.Fragment>Screen <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>SCR-DSH-01</span> · demo dataset · {assets.length} assets</React.Fragment>} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 24 }}>
        <MetricCard label="Total assets" value={assets.length} delta="Main Campus" />
        <MetricCard label="In use" value={count("In use")} delta="On track" deltaTone="up" />
        <MetricCard label="Missing" value={count("Missing")} delta="Needs review" deltaTone="warn" />
        <MetricCard label="Warranty expiring (60d)" value={1} delta="Epson projector" deltaTone="warn" />
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 18 }}>
        <Card>
          <CardTitle>Assets by status</CardTitle>
          <div style={{ display: "flex", height: 140, alignItems: "flex-end", gap: 14, paddingTop: 10 }} role="img" aria-label="Bar chart of assets by status">
            {bars.map((b) => (
              <div key={b.label} style={{ display: "flex", flex: 1, flexDirection: "column", alignItems: "center", gap: 8 }}>
                <div style={{ width: "100%", maxWidth: 34, borderRadius: "4px 4px 0 0", background: b.bg, height: b.value * 28 }}></div>
                <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--text-secondary)" }}>{b.value}</span>
                <span style={{ textAlign: "center", fontSize: 11, color: "var(--text-secondary)" }}>{b.label}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <CardTitle>Recent activity</CardTitle>
          <ActivityFeed items={recentActivity} />
        </Card>
      </div>
    </div>
  );
}

/* ── SCR-AST-01 · Asset list ────────────────────────── */
function AssetsScreen({ onOpen, onRegister }) {
  return (
    <div data-screen-label="Asset list SCR-AST-01">
      <PageHeader title="Asset list"
        sub={<React.Fragment>Screen <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>SCR-AST-01</span> · click a row to open the record</React.Fragment>}
        actions={<Button onClick={onRegister}>+ Register asset</Button>} />
      <Card style={{ padding: 0 }}>
        <AssetTable rows={assets} onOpen={onOpen} />
      </Card>
    </div>
  );
}

/* ── SCR-AST-02 · Asset record ──────────────────────── */
function AssetDetailScreen({ asset, onEdit }) {
  if (!asset) return null;
  const rows = [
    ["Category", asset.category], ["Location", asset.location], ["Department", asset.department],
    ["Assigned to", asset.assignee || "—"],
    ["Status", <StatusPill key="s" status={asset.status} />],
    ["Vendor", asset.vendor], ["Purchase cost", "$" + asset.cost],
    ["Warranty expiry", asset.warranty || "—"],
    ...Object.entries(asset.fields),
  ];
  return (
    <div data-screen-label="Asset record SCR-AST-02">
      <PageHeader
        title={asset.name}
        sub={<React.Fragment><span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>{asset.id}</span> · Screen <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>SCR-AST-02</span></React.Fragment>}
        actions={<Button variant="secondary" onClick={onEdit}>Edit</Button>} />
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 18 }}>
        <Card>
          <CardTitle>Details</CardTitle>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <tbody>
              {rows.map(([k, v]) => (
                <tr key={k}>
                  <td style={{ borderBottom: "1px solid var(--border-hairline)", padding: 12, color: "var(--text-secondary)" }}>{k}</td>
                  <td style={{ borderBottom: "1px solid var(--border-hairline)", padding: 12 }}>{v}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
        <Card>
          <CardTitle>History</CardTitle>
          <ActivityFeed items={[
            { text: "Registered", time: asset.purchased },
            { text: "Assigned to " + asset.department, time: asset.purchased },
            { text: "Status set to " + asset.status, time: "Most recent" },
          ]} />
        </Card>
      </div>
    </div>
  );
}

/* ── SCR-USR-01 · Users ─────────────────────────────── */
function UsersScreen() {
  return (
    <div data-screen-label="Users SCR-USR-01">
      <PageHeader title="Users"
        sub={<React.Fragment>Screen <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>SCR-USR-01</span> · FR-USR-01 through FR-USR-05</React.Fragment>}
        actions={<Button>+ Invite user</Button>} />
      <Card style={{ padding: 0 }}>
        <Table>
          <thead><tr><Th>Name</Th><Th>Role</Th><Th>Department</Th><Th>Status</Th></tr></thead>
          <tbody>
            {users.map((u) => (
              <Tr key={u.email}>
                <Td>{u.name}<br /><span style={{ fontSize: 11.5, color: "var(--text-tertiary)" }}>{u.email}</span></Td>
                <Td><span style={{ borderRadius: "var(--radius-full)", border: "1px solid var(--border-hairline)", background: "var(--surface-app)", padding: "2px 8px", fontSize: 11, color: "var(--text-secondary)" }}>{u.role}</span></Td>
                <Td>{u.department}</Td>
                <Td>
                  <StatusPill status={u.status} />
                  {u.pendingReturns ? <span style={{ marginLeft: 6, fontSize: 11, color: "var(--danger)" }}>{u.pendingReturns} asset pending return</span> : null}
                </Td>
              </Tr>
            ))}
          </tbody>
        </Table>
      </Card>
    </div>
  );
}

/* ── SCR-RPT-01 · Report catalog ────────────────────── */
function ReportsScreen() {
  return (
    <div data-screen-label="Report catalog SCR-RPT-01">
      <PageHeader title="Report catalog"
        sub={<React.Fragment>Screen <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>SCR-RPT-01</span> · FR-RPT-01 through FR-RPT-10</React.Fragment>} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
        {reports.map((r) => <ReportTile key={r.title} icon={r.icon} title={r.title} desc={r.desc} />)}
      </div>
    </div>
  );
}

/* ── SCR-AST-03 · Register asset ────────────────────── */
function RegisterAssetScreen({ onSave }) {
  return (
    <div data-screen-label="Register asset SCR-AST-03">
      <PageHeader title="Register asset"
        sub={<React.Fragment>Screen <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>SCR-AST-03</span> · FR-AST-01, 02, 05, 06</React.Fragment>} />
      <Card>
        <form onSubmit={(e) => { e.preventDefault(); onSave(); }}>
          <div style={{ display: "grid", maxWidth: 620, gridTemplateColumns: "1fr 1fr", gap: 14 }}>
            <div>
              <Label htmlFor="ra-name">Asset name</Label>
              <Input id="ra-name" placeholder="e.g. Dell Latitude 5440" required />
            </div>
            <div>
              <Label htmlFor="ra-category">Category</Label>
              <Select id="ra-category">
                <option>IT equipment</option><option>Furniture</option>
                <option>Vehicle</option><option>Lab equipment</option>
              </Select>
            </div>
            <div>
              <Label htmlFor="ra-manufacturer">Manufacturer</Label>
              <Input id="ra-manufacturer" placeholder="e.g. Dell" />
            </div>
            <div>
              <Label htmlFor="ra-cost">Purchase cost</Label>
              <Input id="ra-cost" inputMode="decimal" placeholder="0.00" />
            </div>
            <div>
              <Label htmlFor="ra-vendor">Vendor</Label>
              <Input id="ra-vendor" placeholder="e.g. TechSupply Wholesale" />
            </div>
            <div>
              <Label htmlFor="ra-location">Location</Label>
              <Select id="ra-location">
                <option>Room 204</option><option>Room 101</option><option>Storage B</option>
              </Select>
            </div>
          </div>
          <div style={{ marginTop: 16 }}><Label>Attachments</Label></div>
          <div style={{ maxWidth: 620, borderRadius: 10, border: "1.5px dashed var(--border-hairline)", padding: 24, textAlign: "center", fontSize: 13, color: "var(--text-tertiary)", boxSizing: "border-box" }}>
            Drop a photo or invoice here, or click to browse
          </div>
          <Button type="submit" style={{ marginTop: 18 }}>Save and generate QR code</Button>
        </form>
      </Card>
    </div>
  );
}

/* ── SCR-AST-04 · Label print queue ─────────────────── */
function LabelsScreen({ onOpen }) {
  return (
    <div data-screen-label="Label print queue SCR-AST-04">
      <PageHeader title="Label print queue"
        sub={<React.Fragment>Screen <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>SCR-AST-04</span> · FR-SCN-07 · Code128 / QR, 2"×1" label stock</React.Fragment>} />
      <Card style={{ padding: 0 }}>
        <AssetTable rows={assets.slice(0, 3)} onOpen={onOpen} />
      </Card>
      <Button style={{ marginTop: 16 }}>Print selected labels</Button>
    </div>
  );
}

/* ── SCR-ORG-01 · Hierarchy setup ───────────────────── */
function HierarchyNode({ label, root }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, lineHeight: 2.3 }}>
      <span style={{ color: "var(--text-tertiary)", display: "inline-flex" }}><Icon name={root ? "network" : "door-open"} size={14} /></span>
      {root ? <strong>{label}</strong> : label}
    </div>
  );
}
function HierarchyChildren({ children }) {
  return <div style={{ marginLeft: 26, borderLeft: "1px solid var(--border-hairline)", paddingLeft: 14 }}>{children}</div>;
}
function HierarchyScreen() {
  return (
    <div data-screen-label="Hierarchy setup SCR-ORG-01">
      <PageHeader title="Hierarchy setup"
        sub={<React.Fragment>Screen <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>SCR-ORG-01</span> · FR-ORG-01, 02, 06</React.Fragment>} />
      <Card>
        <div style={{ fontSize: 13.5 }}>
          <HierarchyNode label="Main Campus" root />
          <HierarchyChildren>
            <HierarchyNode label="Science Building" />
            <HierarchyChildren>
              <HierarchyNode label="Room 101" />
              <HierarchyNode label="Chemistry Lab" />
              <HierarchyNode label="Room 204" />
            </HierarchyChildren>
            <HierarchyNode label="Administration Building" />
            <HierarchyChildren>
              <HierarchyNode label="Office A10" />
              <HierarchyNode label="Boardroom" />
            </HierarchyChildren>
            <HierarchyNode label="Facilities & Storage" />
            <HierarchyChildren>
              <HierarchyNode label="Storage A" />
              <HierarchyNode label="Motor Pool" />
            </HierarchyChildren>
          </HierarchyChildren>
        </div>
        <Button variant="secondary" style={{ marginTop: 16 }}>+ Add node</Button>
      </Card>
    </div>
  );
}

/* ── SCR-SEC-01 · Activity log ──────────────────────── */
function ActivityLogScreen() {
  const events = [
    { time: "09:14", user: "m.reyes", event: "Login success", alert: false },
    { time: "09:02", user: "unknown", event: "Login failed ×3", alert: true },
    { time: "08:55", user: "p.chen", event: "Exported asset register", alert: false },
  ];
  return (
    <div data-screen-label="Activity log SCR-SEC-01">
      <PageHeader title="Activity log"
        sub={<React.Fragment>Screen <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>SCR-SEC-01</span> · FR-SEC-04</React.Fragment>} />
      <Card style={{ padding: 0 }}>
        <Table>
          <thead><tr><Th>Time</Th><Th>User</Th><Th>Event</Th></tr></thead>
          <tbody>
            {events.map((e) => (
              <Tr key={e.time}>
                <Td style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>{e.time}</Td>
                <Td>{e.user}</Td>
                <Td>{e.alert && <StatusPill status="Missing" />} {e.event}</Td>
              </Tr>
            ))}
          </tbody>
        </Table>
      </Card>
    </div>
  );
}

/* ── SCR-CMP-01 · Retention policy ──────────────────── */
function RetentionScreen() {
  const policies = [
    { entity: "Login logs", period: "1 year", action: "Delete" },
    { entity: "Former employee records", period: "2 years", action: "Anonymize" },
    { entity: "Audit evidence", period: "Indefinite", action: "Legal hold eligible" },
  ];
  return (
    <div data-screen-label="Retention policy SCR-CMP-01">
      <PageHeader title="Retention policy"
        sub={<React.Fragment>Screen <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>SCR-CMP-01</span> · FR-CMP-01</React.Fragment>} />
      <Card style={{ padding: 0 }}>
        <Table>
          <thead><tr><Th>Entity type</Th><Th>Retention period</Th><Th>Action at expiry</Th></tr></thead>
          <tbody>
            {policies.map((p) => (
              <Tr key={p.entity}><Td>{p.entity}</Td><Td>{p.period}</Td><Td>{p.action}</Td></Tr>
            ))}
          </tbody>
        </Table>
      </Card>
    </div>
  );
}

/* ── SCR-GLB-03 · Notifications ─────────────────────── */
function NotificationsScreen() {
  return (
    <div data-screen-label="Notifications SCR-GLB-03">
      <PageHeader title="Notifications"
        sub={<React.Fragment>Screen <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>SCR-GLB-03</span> · FR-NTF-03</React.Fragment>} />
      <Card>
        <ActivityFeed items={[
          { text: "3 assets have warranty expiring within 30 days", time: "Today" },
          { text: "AST-00701 marked Missing during last audit", time: "3 days ago", severity: "alert" },
          { text: "J. Ferreira's record is eligible for anonymization review", time: "4 days ago" },
        ]} />
      </Card>
    </div>
  );
}

/* ── R2 locked module ───────────────────────────────── */
function LockedScreen({ name }) {
  return (
    <div data-screen-label={name + " (R2 locked)"}>
      <PageHeader title={name} sub="Release R2 module" />
      <LockPanel name={name} />
    </div>
  );
}

Object.assign(window, { LoginScreen, DashboardScreen, AssetsScreen, AssetDetailScreen, RegisterAssetScreen, LabelsScreen, HierarchyScreen, ActivityLogScreen, RetentionScreen, NotificationsScreen, UsersScreen, ReportsScreen, LockedScreen });
