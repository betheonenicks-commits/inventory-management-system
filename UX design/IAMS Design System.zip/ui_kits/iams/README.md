# IAMS UI Kit

Interactive recreation of the IAMS app (source: `iams-next` Next.js codebase).

- `index.html` — full click-through app. Sign in (any credentials) → dashboard. Sidebar navigates; asset rows open the record view; moon/sun toggles dark mode; R2 modules (Stock, Transfers, Audits, Integrations) show the LockPanel.
- `screens.jsx` — LoginScreen (SCR-GLB-01), DashboardScreen (SCR-DSH-01), AssetsScreen (SCR-AST-01), AssetDetailScreen (SCR-AST-02), RegisterAssetScreen (SCR-AST-03), LabelsScreen (SCR-AST-04), UsersScreen (SCR-USR-01), ReportsScreen (SCR-RPT-01), HierarchyScreen (SCR-ORG-01), ActivityLogScreen (SCR-SEC-01), RetentionScreen (SCR-CMP-01), NotificationsScreen (SCR-GLB-03), LockedScreen (R2).
- `app.jsx` — shell: Sidebar + Topbar + routing + theme state (persisted in localStorage).
- `data.js` — demo fixtures copied verbatim from `lib/data.ts`.

Screens compose the design-system components (`window.IAMSDesignSystem_1406c8`); nothing is re-implemented.
