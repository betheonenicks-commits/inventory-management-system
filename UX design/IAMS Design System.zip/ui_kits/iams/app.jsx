// IAMS app shell — sidebar + topbar + routed content, dark-mode toggle, fake auth.
const { Sidebar, Topbar } = window.IAMSDesignSystem_1406c8;

const ROUTES = {
  "/dashboard": { breadcrumb: "Overview / Dashboard", render: () => <DashboardScreen /> },
  "/assets": { breadcrumb: "Assets / Asset list" },
  "/assets/new": { breadcrumb: "Assets / Register asset" },
  "/labels": { breadcrumb: "Assets / Label queue" },
  "/stock": { breadcrumb: "Inventory / Stock list", locked: "Stock list" },
  "/transfers": { breadcrumb: "Lifecycle / Transfers", locked: "Transfers" },
  "/audits": { breadcrumb: "Audits / Audit list", locked: "Audit list" },
  "/reports": { breadcrumb: "Reports / Report catalog", render: () => <ReportsScreen /> },
  "/hierarchy": { breadcrumb: "Organization / Hierarchy", render: () => <HierarchyScreen /> },
  "/users": { breadcrumb: "Users", render: () => <UsersScreen /> },
  "/activity": { breadcrumb: "Security / Activity log", render: () => <ActivityLogScreen /> },
  "/retention": { breadcrumb: "Security / Retention policy", render: () => <RetentionScreen /> },
  "/integrations": { breadcrumb: "Integrations", locked: "Integrations" },
  "/notifications": { breadcrumb: "Notifications", render: () => <NotificationsScreen /> },
};

function App() {
  const [signedIn, setSignedIn] = React.useState(() => localStorage.getItem("iams-kit-auth") === "1");
  const [route, setRoute] = React.useState(() => localStorage.getItem("iams-kit-route") || "/dashboard");
  const [asset, setAsset] = React.useState(null);
  const [dark, setDark] = React.useState(() => localStorage.getItem("iams-kit-dark") === "1");

  React.useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("iams-kit-dark", dark ? "1" : "0");
  }, [dark]);
  React.useEffect(() => { localStorage.setItem("iams-kit-route", route); }, [route]);
  React.useEffect(() => { localStorage.setItem("iams-kit-auth", signedIn ? "1" : "0"); }, [signedIn]);

  if (!signedIn) return <LoginScreen onSignIn={() => setSignedIn(true)} />;

  const navigate = (href) => { setAsset(null); setRoute(href); };
  const r = ROUTES[route] || ROUTES["/dashboard"];
  const activeHref = route === "/assets/new" ? "/assets" : route;

  let content;
  if (route === "/assets" && asset) {
    content = <AssetDetailScreen asset={asset} onEdit={() => navigate("/assets/new")} />;
  } else if (route === "/assets") {
    content = <AssetsScreen onOpen={setAsset} onRegister={() => navigate("/assets/new")} />;
  } else if (route === "/assets/new") {
    content = <RegisterAssetScreen onSave={() => navigate("/assets")} />;
  } else if (route === "/labels") {
    content = <LabelsScreen onOpen={(a) => { setRoute("/assets"); setAsset(a); }} />;
  } else if (r.locked) {
    content = <LockedScreen name={r.locked} />;
  } else {
    content = r.render();
  }

  return (
    <div style={{ display: "grid", height: "100vh", gridTemplateColumns: "232px 1fr" }}>
      <Sidebar activeHref={activeHref} onNavigate={navigate} />
      <div style={{ display: "flex", minWidth: 0, flexDirection: "column" }}>
        <Topbar breadcrumb={r.breadcrumb} dark={dark} onToggleTheme={() => setDark(!dark)} onBell={() => navigate("/notifications")} />
        <main style={{ flex: 1, overflowY: "auto", padding: "28px 32px 64px", background: "var(--surface-app)" }}>{content}</main>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
